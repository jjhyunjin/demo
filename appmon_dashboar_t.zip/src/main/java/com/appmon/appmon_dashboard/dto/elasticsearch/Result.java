package com.appmon.appmon_dashboard.dto.elasticsearch;

import java.io.Serializable;

public class Result implements Serializable {
    private static final long serialVersionUID = 1;

    private int took;
    private  boolean time_out;
    private Shared _shard;
    private Hit hits;

    public int getTook() {
        return took;
    }

    public void setTook(int took) {
        this.took = took;
    }

    public boolean isTime_out() {
        return time_out;
    }

    public void setTime_out(boolean time_out) {
        this.time_out = time_out;
    }

    public Shared get_shard() {
        return _shard;
    }

    public void set_shard(Shared _shard) {
        this._shard = _shard;
    }

    public Hit getHits() {
        return hits;
    }

    public void setHits(Hit hits) {
        this.hits = hits;
    }
}
