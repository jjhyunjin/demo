package com.appmon.appmon_dashboard.service;

import org.elasticsearch.action.search.SearchResponse;

public interface DashBoardService {
    SearchResponse getRealtimeTable(String startDate, String endDate);

    SearchResponse getRealtimeGrape(String startDate, String endDate);
}
