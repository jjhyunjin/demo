package com.appmon.appmon_dashboard.controller;

import com.appmon.appmon_dashboard.service.DashBoardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.text.SimpleDateFormat;
import java.util.Calendar;

@Controller
public class DashBoardController {
    /*
    @RequestMapping("/")
    public String index(){
        return "/dashboard/realtime_dashboard";
    }

    @RequestMapping("/dashboard/realtime")
    public String index1(){
        return "/dashboard/realtime_dashboard";
    }
*/
    @Autowired
    protected DashBoardService dashBoardService;

    private static final String VIEW_PATH = "dashboard/";

    @RequestMapping( value = "/dashboard", method = RequestMethod.GET )
    public ModelAndView dashboard(Model model
            , @RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            , @RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            endDate = sdf.format(cal.getTime());
            // 5분전
            cal.add(Calendar.MINUTE, -5);
            startDate = sdf.format(cal.getTime());
        }

        // Result tableResult = dashBoardService.getRealtimeTable(startDate, endDate);
        //List<HitBlock> errBlockList = tableResult.getHits().getHits();

        // Result grapeResult = dashBoardService.getRealtimeGrape(startDate, endDate);



        return new ModelAndView("dashboard/realtime_dashboard", "list", null);

    }


    @RequestMapping( value = "/dashboard/realtime/grape", method = RequestMethod.GET )
    @ResponseBody
    public String realTimeGrape(Model model
            ,@RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            ,@RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            endDate = sdf.format(cal.getTime());
            // 5분전
            cal.add(Calendar.MINUTE, -5);
            startDate = sdf.format(cal.getTime());
        }

        //Result grapeResult = dashBoardService.getRealtimeGrape(startDate, endDate);

        return dashBoardService.getRealtimeGrape(startDate, endDate).toString();
    }

    @RequestMapping( value = "/dashboard/realtime/table", method = RequestMethod.GET )
    @ResponseBody
    public String realTimeTable(Model model
            ,@RequestParam(value="startDate", defaultValue = "", required = false) String startDate
            ,@RequestParam(value="endDate", defaultValue = "", required = false) String endDate
    ){
        // 시간을 선택하지 않았을 경우
        if(StringUtils.isEmpty(startDate) || StringUtils.isEmpty(endDate) ){
            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
            Calendar cal = Calendar.getInstance();
            endDate = sdf.format(cal.getTime());
            // 5분전
            cal.add(Calendar.MINUTE, -5);
            startDate = sdf.format(cal.getTime());
        }

        return  dashBoardService.getRealtimeTable(startDate, endDate).toString();
    }



}
